package com.example.pmastanic;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class StudentActivity extends AppCompatActivity {
    private AutoCompleteTextView autoCompleteSubject;
    private TextInputEditText editTextProfessorName;
    private TextInputEditText editTextLectureHours;
    private TextInputEditText editTextLabHours;
    private SwitchMaterial switchSubjectStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        autoCompleteSubject = findViewById(R.id.autoCompleteTextView);
        editTextProfessorName = findViewById(R.id.editTextProfessorName);
        editTextLectureHours = findViewById(R.id.editTextLectureHours);
        editTextLabHours = findViewById(R.id.editTextLabHours);
        switchSubjectStatus = findViewById(R.id.switchSubjectStatus);
        Button buttonNextStudent = findViewById(R.id.btnUnesi);

        // Retrieve data from PersonalInfoActivity
        String name = getIntent().getStringExtra("name");
        String surname = getIntent().getStringExtra("surname");
        String birthDate = getIntent().getStringExtra("dateOfBirth");

        // Show a toast with the received data
        Toast.makeText(StudentActivity.this, "Prezime: " + surname + ", Datum rođenja: " + birthDate, Toast.LENGTH_SHORT).show();

        // Handle button click to proceed to next activity
        buttonNextStudent.setOnClickListener(view -> {
            String subject = autoCompleteSubject.getText().toString().trim();
            String professorName = editTextProfessorName.getText().toString().trim();
            String lectureHours = editTextLectureHours.getText().toString().trim();
            String labHours = editTextLabHours.getText().toString().trim();
            boolean isMandatory = switchSubjectStatus.isChecked();

            if (!subject.isEmpty() && !professorName.isEmpty() && !lectureHours.isEmpty() && !labHours.isEmpty()) {
                Intent intent = new Intent(StudentActivity.this, SummaryActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("surname", surname);
                intent.putExtra("dateOfBirth", birthDate);
                intent.putExtra("subject", subject);
                intent.putExtra("professorName", professorName);
                intent.putExtra("lectureHours", Integer.parseInt(lectureHours));
                intent.putExtra("labHours", Integer.parseInt(labHours));
                intent.putExtra("isMandatory", isMandatory);
                startActivity(intent);
            } else {
                Toast.makeText(StudentActivity.this, "Molimo unesite sve podatke", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
