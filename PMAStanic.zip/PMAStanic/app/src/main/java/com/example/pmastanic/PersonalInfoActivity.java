package com.example.pmastanic;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputLayout;

public class PersonalInfoActivity extends AppCompatActivity {
    private TextInputLayout nameInputLayout, surnameInputLayout, dateOfBirthInputLayout;
    private EditText dateOfBirthEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);

        ImageView profileImageView = findViewById(R.id.imageViewProfile);
        nameInputLayout = findViewById(R.id.textInputLayoutName);
        surnameInputLayout = findViewById(R.id.textInputLayoutSurname);
        dateOfBirthInputLayout = findViewById(R.id.textInputLayoutDateOfBirth);
        dateOfBirthEditText = findViewById(R.id.editTextDateOfBirth);
        nextButton = findViewById(R.id.buttonNext);

        // Set up date picker for date of birth
        dateOfBirthEditText.setOnClickListener(v -> {
            MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker().build();
            datePicker.show(getSupportFragmentManager(), "DATE_PICKER");

            datePicker.addOnPositiveButtonClickListener(selection -> {
                dateOfBirthEditText.setText(datePicker.getHeaderText());
            });
        });

        // Handle the next button click to pass data to StudentActivity
        nextButton.setOnClickListener(v -> {
            String name = nameInputLayout.getEditText().getText().toString().trim();
            String surname = surnameInputLayout.getEditText().getText().toString().trim();
            String dateOfBirth = dateOfBirthEditText.getText().toString().trim();

            if (!name.isEmpty() && !surname.isEmpty() && !dateOfBirth.isEmpty()) {
                Intent intent = new Intent(PersonalInfoActivity.this, StudentActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("surname", surname);
                intent.putExtra("dateOfBirth", dateOfBirth);
                startActivity(intent);
            } else {
                Toast.makeText(PersonalInfoActivity.this, "Unesite sve podatke!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
