package com.example.pmastanic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;

public class SummaryActivity extends AppCompatActivity {

    private TextView textViewName, textViewSurname, textViewDateOfBirth;
    private TextView textViewSubject, textViewProfessorName;
    private TextView textViewLectureHours, textViewLabHours, textViewSubjectStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        // Initialize TextViews
        textViewName = findViewById(R.id.textViewName);
        textViewSurname = findViewById(R.id.textViewSurname);
        textViewDateOfBirth = findViewById(R.id.textViewDateOfBirth);
        textViewSubject = findViewById(R.id.textViewSubject);
        textViewProfessorName = findViewById(R.id.textViewProfessorName);
        textViewLectureHours = findViewById(R.id.textViewLectureHours);
        textViewLabHours = findViewById(R.id.textViewLabHours);
        textViewSubjectStatus = findViewById(R.id.textViewSubjectStatus);
        Button buttonBack = findViewById(R.id.btnPocetak);

        // Retrieve and display information from previous activities
        Intent intent = getIntent();

        // Personal Info
        String name = ((Intent) intent).getStringExtra("name");
        String surname = intent.getStringExtra("surname");
        String dateOfBirth = intent.getStringExtra("dateOfBirth");

        // Subject Info
        String subject = intent.getStringExtra("subject");
        String professorName = intent.getStringExtra("professorName");
        int lectureHours = intent.getIntExtra("lectureHours", 0);
        int labHours = intent.getIntExtra("labHours", 0);
        boolean isMandatory = intent.getBooleanExtra("isMandatory", true);

        // Set text values to TextViews
        textViewName.setText(name);
        textViewSurname.setText(surname);
        textViewDateOfBirth.setText(dateOfBirth);
        textViewSubject.setText(subject);
        textViewProfessorName.setText(professorName);
        textViewLectureHours.setText(String.valueOf(lectureHours));
        textViewLabHours.setText(String.valueOf(labHours));
        textViewSubjectStatus.setText(isMandatory ? "Obavezni" : "Izborni");

        buttonBack.setOnClickListener(view -> {
            Intent intent2 = new Intent(SummaryActivity.this, PersonalInfoActivity.class);
            intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent2);
            finish();
        });


    }
}
